import numpy as np
import cv2
import time

class Homography:
    def solve_homography(self, S, D):
        """
        Computes the 3x3 homography matrix H such that D = H * S.
        Uses the DLT (Direct Linear Transform) algorithm from CW1.
        For each point pair we get 2 equations, stacked into matrix A.
        Solving Ah=0 via SVD gives us H as the last row of V^T reshaped to 3x3.

        S: source points (Nx2)
        D: destination points (Nx2)
        Returns: H (3x3 homography matrix)
        """
        A = []
        for i in range(len(S)):
            x, y   = S[i]
            xp, yp = D[i]
            A.append([-x, -y, -1,  0,  0,  0, xp*x, xp*y, xp])
            A.append([ 0,  0,  0, -x, -y, -1, yp*x, yp*y, yp])
        A = np.array(A)
        _, _, Vt = np.linalg.svd(A)
        H = Vt[-1].reshape(3, 3)
        H = H / H[2, 2]  # normalise so H[2,2]=1
        return H


class Blender:
    def linear_blending(self, img_left, img_right, overlap_x):
        """
        Linear (feathering) blending in the overlap region.
        Gradually transitions from left image to right image across the overlap zone.
        Outside the overlap, pixels come fully from one image.

        img_left:  left panorama canvas (H x W x 3)
        img_right: right image warped onto same canvas (H x W x 3)
        overlap_x: x-coordinate where overlap begins
        Returns: blended image
        """
        result = img_left.copy().astype(np.float32)
        h, w = img_left.shape[:2]

        # Find the right edge of the overlap (where right image pixels start being 0)
        right_mask = (img_right > 0).any(axis=2)
        left_mask  = (img_left  > 0).any(axis=2)
        overlap    = right_mask & left_mask

        for col in range(w):
            if not overlap[:, col].any():
                # No overlap — just take whichever image has content
                mask = right_mask[:, col]
                result[mask, col] = img_right[mask, col]
                continue

            # Work out blend weight: 0=fully left, 1=fully right
            cols_in_overlap = np.where(overlap.any(axis=0))[0]
            if len(cols_in_overlap) == 0:
                continue
            x_start = cols_in_overlap[0]
            x_end   = cols_in_overlap[-1]
            alpha   = (col - x_start) / max(x_end - x_start, 1)
            alpha   = np.clip(alpha, 0, 1)

            rows = overlap[:, col]
            result[rows, col] = (
                (1 - alpha) * img_left[rows, col].astype(np.float32) +
                alpha       * img_right[rows, col].astype(np.float32)
            )
            # Right-only pixels
            right_only = right_mask[:, col] & ~left_mask[:, col]
            result[right_only, col] = img_right[right_only, col]

        return np.clip(result, 0, 255).astype(np.uint8)

    def customised_blending(self, img_left, img_right):
        """
        Multiband blending using Laplacian pyramids.
        Builds Gaussian pyramids for both images and a mask,
        then blends each frequency band separately before reconstructing.
        This avoids the ghosting/hard edge of simple linear blending.

        img_left:  left canvas
        img_right: right canvas (warped)
        Returns: blended image
        """
        levels = 5
        h, w = img_left.shape[:2]

        # Build mask: 1 = left side, 0 = right side, smooth transition in middle
        mask = np.zeros((h, w), dtype=np.float32)
        right_cols = np.where((img_right > 0).any(axis=0).any(axis=1) if img_right.ndim==3
                              else (img_right > 0).any(axis=0))[0]
        left_cols  = np.where((img_left > 0).any(axis=0).any(axis=1) if img_left.ndim==3
                              else (img_left > 0).any(axis=0))[0]

        if len(right_cols) > 0 and len(left_cols) > 0:
            split = (left_cols[-1] + right_cols[0]) // 2
        else:
            split = w // 2

        mask[:, :split] = 1.0
        # Smooth transition
        blend_width = 50
        for i in range(blend_width):
            col = split - blend_width//2 + i
            if 0 <= col < w:
                mask[:, col] = 1.0 - (i / blend_width)

        mask3 = np.stack([mask]*3, axis=2)

        # Gaussian pyramids
        def gauss_pyr(img, lvls):
            pyr = [img.astype(np.float32)]
            for _ in range(lvls - 1):
                pyr.append(cv2.pyrDown(pyr[-1]))
            return pyr

        # Laplacian pyramids
        def lap_pyr(img, lvls):
            gp = gauss_pyr(img, lvls)
            lp = []
            for i in range(lvls - 1):
                up = cv2.pyrUp(gp[i+1], dstsize=(gp[i].shape[1], gp[i].shape[0]))
                lp.append(gp[i] - up)
            lp.append(gp[-1])
            return lp

        lp_l = lap_pyr(img_left,  levels)
        lp_r = lap_pyr(img_right, levels)
        gp_m = gauss_pyr(mask3,   levels)

        # Blend each level
        blended = []
        for la, lb, gm in zip(lp_l, lp_r, gp_m):
            gm_r = cv2.resize(gm, (la.shape[1], la.shape[0]))
            blended.append(gm_r * la + (1 - gm_r) * lb)

        # Reconstruct from pyramid
        result = blended[-1]
        for i in range(levels - 2, -1, -1):
            result = cv2.pyrUp(result, dstsize=(blended[i].shape[1], blended[i].shape[0]))
            result = result + blended[i]

        return np.clip(result, 0, 255).astype(np.uint8)


class Stitcher:
    def __init__(self):
        self.homography_solver = Homography()
        self.blender = Blender()

    def stitch(self, img_left, img_right, blend_mode='linear'):
        """
        Main stitching pipeline:
        1. Detect keypoints + descriptors (SIFT)
        2. Match descriptors using ratio test
        3. Draw matches
        4. Estimate homography with RANSAC
        5. Warp and stitch
        6. Blend
        7. Remove black border

        img_left, img_right: input BGR images
        blend_mode: 'linear', 'multiband', or 'none'
        Returns: stitched panorama
        """
        print("Step 1: Computing descriptors...")
        kp_l, desc_l = self.compute_descriptors(img_left)
        kp_r, desc_r = self.compute_descriptors(img_right)

        print("Step 2: Matching features...")
        matches = self.matching(kp_l, kp_r, desc_l, desc_r, ratio=0.75)
        print(f"Number of matching correspondences selected: {len(matches)}")

        print("Step 3: Drawing matches...")
        self.draw_matches(img_left, img_right, matches)

        print("Step 4: Finding homography with RANSAC...")
        H = self.find_homography(matches)

        print("Step 5: Warping and stitching...")
        result = self.warping(img_left, img_right, H, blend_mode=blend_mode)

        print("Step 6: Removing black border...")
        result = self.remove_black_border(result)

        return result

    def compute_descriptors(self, img):
        """
        Detects keypoints and computes SIFT descriptors.
        SIFT (Scale Invariant Feature Transform) finds distinctive corners/blobs
        that are stable across scale and rotation changes — ideal for matching
        overlapping photos taken from different angles.

        img: BGR image
        Returns: keypoints list, descriptors array (Nx128)
        """
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        sift = cv2.SIFT_create()
        keypoints, descriptors = sift.detectAndCompute(gray, None)
        return keypoints, descriptors

    def matching(self, kp_l, kp_r, desc_l, desc_r, ratio=0.75):
        """
        Matches descriptors between two images using brute-force L2 distance.
        We implement our own ratio test (Lowe's ratio test):
        a match is only kept if the best match distance is significantly
        smaller than the second-best. This filters out ambiguous matches.

        ratio: threshold — lower = stricter (0.75 is standard)
        Returns: list of good matches as (keypoint_left, keypoint_right) tuples
        """
        good_matches = []

        for i, d1 in enumerate(desc_l):
            # Compute L2 distance from descriptor i in left to ALL right descriptors
            distances = np.linalg.norm(desc_r - d1, axis=1)

            # Get the two best (smallest distance) matches
            idx_sorted = np.argsort(distances)
            best       = idx_sorted[0]
            second     = idx_sorted[1]

            # Lowe ratio test: keep only unambiguous matches
            if distances[best] < ratio * distances[second]:
                good_matches.append((kp_l[i], kp_r[best]))

        return good_matches

    def draw_matches(self, img_left, img_right, matches):
        """
        Draws lines connecting matched keypoints between the two images.
        Places both images side by side and draws a coloured circle + line
        for each correspondence so you can visually verify match quality.

        Saves result as 'matches.jpg' and displays it.
        """
        h1, w1 = img_left.shape[:2]
        h2, w2 = img_right.shape[:2]

        # Canvas wide enough for both images side by side
        canvas = np.zeros((max(h1, h2), w1 + w2, 3), dtype=np.uint8)
        canvas[:h1, :w1]        = img_left
        canvas[:h2, w1:w1 + w2] = img_right

        for kp_l, kp_r in matches:
            pt_l = (int(kp_l.pt[0]),       int(kp_l.pt[1]))
            pt_r = (int(kp_r.pt[0]) + w1,  int(kp_r.pt[1]))
            color = tuple(np.random.randint(0, 255, 3).tolist())
            cv2.circle(canvas, pt_l, 4, color, 1)
            cv2.circle(canvas, pt_r, 4, color, 1)
            cv2.line(canvas, pt_l, pt_r, color, 1)

        cv2.imwrite('matches.jpg', canvas)
        cv2.imshow('correspondences', canvas)
        cv2.waitKey(0)

    def find_homography(self, matches, n_iters=2000, threshold=5.0):
        """
        RANSAC (Random Sample Consensus) homography estimation.

        Standard homography needs 4 point pairs minimum.
        RANSAC works by:
        1. Randomly sampling 4 matches
        2. Computing H from those 4 points
        3. Testing H against ALL matches — count inliers (reprojection error < threshold)
        4. Repeat n_iters times, keep the H with the most inliers
        5. Refit H using ALL inliers of the best model

        This makes it robust to wrong matches (outliers).

        threshold: max reprojection error (pixels) to count as inlier
        Returns: best homography H (3x3)
        """
        # Convert matches to arrays of (x,y) points
        pts_l = np.array([m[0].pt for m in matches], dtype=np.float32)
        pts_r = np.array([m[1].pt for m in matches], dtype=np.float32)

        best_H       = None
        best_inliers = []

        for _ in range(n_iters):
            # 1. Random sample of 4 matches
            idx    = np.random.choice(len(matches), 4, replace=False)
            src    = pts_l[idx]
            dst    = pts_r[idx]

            # 2. Compute homography from these 4 points
            H = self.homography_solver.solve_homography(src, dst)

            # 3. Reproject all left points using H, measure error vs right points
            ones  = np.ones((len(pts_l), 1))
            pts_h = np.hstack([pts_l, ones])          # Nx3 homogeneous
            proj  = (H @ pts_h.T).T                   # Nx3
            proj  = proj / proj[:, 2:3]               # normalise
            proj  = proj[:, :2]                       # back to (x,y)

            errors  = np.linalg.norm(proj - pts_r, axis=1)
            inliers = np.where(errors < threshold)[0]

            # 4. Keep best
            if len(inliers) > len(best_inliers):
                best_inliers = inliers
                best_H       = H

        # 5. Refit using all inliers of best model
        if len(best_inliers) >= 4:
            best_H = self.homography_solver.solve_homography(
                pts_l[best_inliers], pts_r[best_inliers]
            )

        print(f"  RANSAC: {len(best_inliers)} inliers from {len(matches)} matches")
        return best_H

    def warping(self, img_left, img_right, H, blend_mode='linear'):
        """
        Warps img_left into the coordinate frame of img_right using homography H,
        then places both on a shared canvas to create the panorama.

        We implement inverse warping: for each output pixel, we compute where it
        came from in img_left using H_inv, then bilinear interpolate.
        This avoids holes that forward warping creates.

        H: homography mapping left -> right
        blend_mode: how to blend the overlap region
        Returns: stitched image
        """
        h_l, w_l = img_left.shape[:2]
        h_r, w_r = img_right.shape[:2]

        # Find where the corners of img_left end up after warping
        corners_l = np.array([[0,0],[w_l,0],[w_l,h_l],[0,h_l]], dtype=np.float32)
        ones      = np.ones((4,1))
        corners_h = np.hstack([corners_l, ones])
        warped_c  = (H @ corners_h.T).T
        warped_c  = warped_c / warped_c[:, 2:3]
        warped_c  = warped_c[:, :2]

        # Combine with right image corners to get full canvas size
        all_corners = np.vstack([warped_c, [[0,0],[w_r,0],[w_r,h_r],[0,h_r]]])
        x_min, y_min = np.floor(all_corners.min(axis=0)).astype(int)
        x_max, y_max = np.ceil(all_corners.max(axis=0)).astype(int)

        # Translation so everything fits on canvas
        tx = -x_min
        ty = -y_min
        canvas_w = x_max - x_min
        canvas_h = y_max - y_min

        T = np.array([[1, 0, tx],
                      [0, 1, ty],
                      [0, 0,  1]], dtype=np.float64)

        # Warp left image onto canvas using inverse mapping
        H_inv    = np.linalg.inv(T @ H)
        warped_l = cv2.warpPerspective(img_left, T @ H, (canvas_w, canvas_h))

        # Place right image on canvas with translation offset
        canvas_r = np.zeros((canvas_h, canvas_w, 3), dtype=np.uint8)
        canvas_r[ty:ty+h_r, tx:tx+w_r] = img_right

        # Blend
        if blend_mode == 'linear':
            overlap_x = tx  # rough estimate
            result = self.blender.linear_blending(warped_l, canvas_r, overlap_x)
        elif blend_mode == 'multiband':
            result = self.blender.customised_blending(warped_l, canvas_r)
        else:
            # Simple overwrite — right image on top in overlap
            result = warped_l.copy()
            mask   = canvas_r > 0
            result[mask] = canvas_r[mask]

        return result

    def remove_black_border(self, img):
        """
        Crops the black borders left after warping.
        Converts to greyscale, thresholds to find non-black pixels,
        finds the bounding rectangle of all content, and crops to it.

        Returns: cropped image with black borders removed
        """
        gray    = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)

        # Find bounding box of non-zero pixels
        coords = cv2.findNonZero(mask)
        x, y, w, h = cv2.boundingRect(coords)
        cropped = img[y:y+h, x:x+w]
        return cropped


if __name__ == "__main__":
    t_start = time.time()

    # Read images
    img_left  = cv2.imread('s1.jpg')
    img_right = cv2.imread('s2.jpg')

    if img_left is None or img_right is None:
        print("ERROR: Could not load images. Make sure s1.jpg and s2.jpg are in the same folder.")
        exit()

    print(f"Left image:  {img_left.shape}")
    print(f"Right image: {img_right.shape}")

    stitcher = Stitcher()

    # Run with linear blending (change to 'multiband' or 'none' to try others)
    result = stitcher.stitch(img_left, img_right, blend_mode='linear')

    t_end = time.time()
    print(f"\nTotal time: {t_end - t_start:.2f} seconds")

    # Save and show result
    cv2.imwrite('panorama_result.jpg', result)
    print("Saved as panorama_result.jpg")

    cv2.imshow('result', result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
